import { css } from '@emotion/react';

import Skeleton from '@TutorShared/atoms/Skeleton';

import { spacing } from '@TutorShared/config/styles';

const SkeletonLoader = () => {
  return (
    <div css={styles.container}>
      <div css={styles.wrapper}>
        <Skeleton animation={true} isMagicAi width="20%" height="12px" />
        <Skeleton animation={true} isMagicAi width="100%" height="12px" />
        <Skeleton animation={true} isMagicAi width="100%" height="12px" />
        <Skeleton animation={true} isMagicAi width="40%" height="12px" />
      </div>
      <div css={styles.wrapper}>
        <Skeleton animation={true} isMagicAi width="80%" height="12px" />
        <Skeleton animation={true} isMagicAi width="100%" height="12px" />
        <Skeleton animation={true} isMagicAi width="80%" height="12px" />
      </div>
    </div>
  );
};

export default SkeletonLoader;

const styles = {
  wrapper: css`
    display: flex;
    flex-direction: column;
    gap: ${spacing[8]};
  `,
  container: css`
    display: flex;
    flex-direction: column;
    gap: ${spacing[32]};
  `,
};
