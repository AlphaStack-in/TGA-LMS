import React, { type ChangeEventHandler, type FocusEventHandler, type ReactNode } from 'react';
import { css, type SerializedStyles } from '@emotion/react';

import { colorTokens, spacing } from '@TutorShared/config/styles';
import { typography } from '@TutorShared/config/typography';
import { styleUtils } from '@TutorShared/utils/style-utils';
import { nanoid } from '@TutorShared/utils/util';

interface RadioProps {
  id?: string;
  label?: string;
  description?: string;
  icon?: ReactNode;
  value?: string | number;
  name?: string;
  checked?: boolean;
  readOnly?: boolean;
  disabled?: boolean;
  labelCss?: SerializedStyles;
  inputCss?: SerializedStyles[];
  onChange?: ChangeEventHandler<HTMLInputElement> | undefined;
  onBlur?: FocusEventHandler<HTMLInputElement> | undefined;
}

const Radio = React.forwardRef<HTMLInputElement, RadioProps>((props: RadioProps, ref) => {
  const {
    name,
    checked,
    readOnly,
    disabled = false,
    labelCss,
    label,
    icon,
    value,
    onChange,
    onBlur,
    description,
  } = props;
  const id = nanoid();

  return (
    <div css={styles.wrapper}>
      <label htmlFor={id} css={[styles.container(disabled), labelCss]}>
        <input
          ref={ref}
          id={id}
          name={name}
          type="radio"
          checked={checked}
          readOnly={readOnly}
          value={value}
          disabled={disabled}
          onChange={onChange}
          onBlur={onBlur}
          css={[styles.radio(label)]}
        />
        <span />
        {icon}
        {label}
      </label>
      {description && <p css={styles.description}>{description}</p>}
    </div>
  );
});

const styles = {
  wrapper: css`
    ${styleUtils.display.flex('column')};
    gap: ${spacing[8]};
  `,
  container: (disabled: boolean) => css`
    ${typography.caption()};
    display: flex;
    align-items: center;
    cursor: pointer;
    user-select: none;

    ${disabled &&
    css`
      color: ${colorTokens.text.disable};
    `}
  `,
  radio: (label = '') => css`
    position: absolute;
    opacity: 0;
    height: 0;
    width: 0;
    cursor: pointer;

    & + span {
      position: relative;
      cursor: pointer;
      height: 18px;
      width: 18px;
      background-color: ${colorTokens.background.white};
      border: 2px solid ${colorTokens.stroke.default};
      border-radius: 100%;
      ${label &&
      css`
        margin-right: ${spacing[10]};
      `}
    }
    & + span::before {
      content: '';
      position: absolute;
      left: 3px;
      top: 3px;
      background-color: ${colorTokens.background.white};
      width: 8px;
      height: 8px;
      border-radius: 100%;
    }
    &:checked + span {
      border-color: ${colorTokens.action.primary.default};
    }
    &:checked + span::before {
      background-color: ${colorTokens.action.primary.default};
    }

    &:focus-visible {
      & + span {
        outline: 2px solid ${colorTokens.stroke.brand};
        outline-offset: 1px;
      }
    }
  `,
  description: css`
    ${typography.small()};
    color: ${colorTokens.text.hints};
    padding-left: 30px;
  `,
};

export default Radio;
