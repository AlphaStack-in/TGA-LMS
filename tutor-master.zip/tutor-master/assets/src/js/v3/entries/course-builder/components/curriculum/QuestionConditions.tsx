import { useCallback, useEffect } from 'react';
import { Controller, useFormContext } from 'react-hook-form';
import { css } from '@emotion/react';
import { __ } from '@wordpress/i18n';

import Button from '@TutorShared/atoms/Button';
import SVGIcon from '@TutorShared/atoms/SVGIcon';
import Tooltip from '@TutorShared/atoms/Tooltip';

import FormInput from '@TutorShared/components/fields/FormInput';
import FormSwitch from '@TutorShared/components/fields/FormSwitch';
import { useModal } from '@TutorShared/components/modals/Modal';

import { colorTokens, spacing } from '@TutorShared/config/styles';
import { typography } from '@TutorShared/config/typography';
import Show from '@TutorShared/controls/Show';
import { getQuestionTypeConfig } from '@TutorShared/utils/question-type-registry';
import { calculateQuizDataStatus } from '@TutorShared/utils/quiz';
import { styleUtils } from '@TutorShared/utils/style-utils';
import { QuizDataStatus } from '@TutorShared/utils/types';

import CourseBuilderInjectionSlot from '@CourseBuilderComponents/CourseBuilderSlot';
import QuestionPreviewModal from '@CourseBuilderComponents/modals/QuestionPreviewModal';
import { useQuizModalContext } from '@CourseBuilderContexts/QuizModalContext';
import { type QuizForm } from '@CourseBuilderServices/quiz';

const QuestionConditions = () => {
  const { activeQuestionIndex, activeQuestionId, validationError, setValidationError } = useQuizModalContext();
  const form = useFormContext<QuizForm>();
  const { showModal, closeModal } = useModal();

  const activeQuestion = form.watch(`questions.${activeQuestionIndex}` as 'questions.0');
  const activeQuestionType = form.watch(`questions.${activeQuestionIndex}.question_type`);
  const activeDataStatus = form.watch(`questions.${activeQuestionIndex}._data_status`);

  const handlePreview = useCallback(() => {
    showModal({
      component: QuestionPreviewModal,
      props: {
        question: activeQuestion,
        onClose: () => closeModal(),
      },
    });
  }, [activeQuestion, showModal, closeModal]);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.altKey && event.code === 'KeyP') {
        event.preventDefault();
        handlePreview();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handlePreview]);

  if (!activeQuestionId) {
    return <p css={styles.emptyQuestions}>{__('Create/Select a question to view details', 'tutor')}</p>;
  }

  return (
    <div key={`${activeQuestionId}-${activeQuestionIndex}`}>
      <div css={styles.questionTypeWrapper}>
        <div css={typography.caption('medium')}>{__('Question Type', 'tutor')}</div>
        <div css={styles.questionTypeRow}>
          <div css={styles.questionType}>
            <SVGIcon
              name={
                activeQuestionType
                  ? (getQuestionTypeConfig(activeQuestionType)?.icon ?? 'quizTrueFalse')
                  : 'quizTrueFalse'
              }
              width={32}
              height={32}
            />
            <span>{activeQuestionType ? (getQuestionTypeConfig(activeQuestionType)?.label ?? '') : ''}</span>
          </div>

          <Tooltip content={__('Preview (Option/Alt + P)', 'tutor')}>
            <Button
              isOutlined
              variant="primary"
              size="small"
              icon={<SVGIcon name="preview2" width={24} height={24} />}
              onClick={handlePreview}
            >
              {__('Preview', 'tutor')}
            </Button>
          </Tooltip>
        </div>
      </div>

      <div css={styles.conditions}>
        <p>{__('Conditions:', 'tutor')}</p>

        <div css={styles.conditionControls}>
          <Show when={activeQuestionType === 'multiple_choice'}>
            <Controller
              control={form.control}
              name={
                `questions.${activeQuestionIndex}.question_settings.has_multiple_correct_answer` as 'questions.0.question_settings.has_multiple_correct_answer'
              }
              render={(controllerProps) => (
                <FormSwitch
                  {...controllerProps}
                  label={__('Multiple Correct Answer', 'tutor')}
                  onChange={(value) => {
                    if (calculateQuizDataStatus(activeDataStatus, QuizDataStatus.UPDATE)) {
                      form.setValue(
                        `questions.${activeQuestionIndex}._data_status`,
                        calculateQuizDataStatus(activeDataStatus, QuizDataStatus.UPDATE) as QuizDataStatus,
                      );
                    }

                    // Reset all answers to incorrect on multiple correct answer toggle from true to false
                    if (!value) {
                      form.setValue(
                        `questions.${activeQuestionIndex}.question_answers`,
                        form.getValues(`questions.${activeQuestionIndex}.question_answers`).map((answer) => {
                          return {
                            ...answer,
                            is_correct: '0' as '0' | '1',
                          };
                        }),
                      );
                    }
                  }}
                />
              )}
            />
          </Show>

          <Show when={activeQuestionType === 'matching'}>
            <Controller
              control={form.control}
              name={
                `questions.${activeQuestionIndex}.question_settings.is_image_matching` as 'questions.0.question_settings.is_image_matching'
              }
              render={(controllerProps) => (
                <FormSwitch
                  {...controllerProps}
                  label={__('Image Matching', 'tutor')}
                  onChange={(value) => {
                    if (calculateQuizDataStatus(activeDataStatus, QuizDataStatus.UPDATE)) {
                      form.setValue(
                        `questions.${activeQuestionIndex}._data_status`,
                        calculateQuizDataStatus(activeDataStatus, QuizDataStatus.UPDATE) as QuizDataStatus,
                      );
                    }

                    if (validationError?.type === 'question' && !value) {
                      setValidationError(null);
                    }
                  }}
                />
              )}
            />
          </Show>

          <Controller
            control={form.control}
            name={
              `questions.${activeQuestionIndex}.question_settings.answer_required` as 'questions.0.question_settings.answer_required'
            }
            render={(controllerProps) => (
              <FormSwitch
                {...controllerProps}
                label={__('Answer Required', 'tutor')}
                onChange={() => {
                  if (calculateQuizDataStatus(activeDataStatus, QuizDataStatus.UPDATE)) {
                    form.setValue(
                      `questions.${activeQuestionIndex}._data_status`,
                      calculateQuizDataStatus(activeDataStatus, QuizDataStatus.UPDATE) as QuizDataStatus,
                    );
                  }
                }}
              />
            )}
          />

          <Show when={getQuestionTypeConfig(activeQuestionType)?.supportsRandomize}>
            <Controller
              control={form.control}
              name={
                `questions.${activeQuestionIndex}.question_settings.randomize_question` as 'questions.0.question_settings.randomize_question'
              }
              render={(controllerProps) => (
                <FormSwitch
                  {...controllerProps}
                  label={__('Randomize Choice', 'tutor')}
                  onChange={() => {
                    if (calculateQuizDataStatus(activeDataStatus, QuizDataStatus.UPDATE)) {
                      form.setValue(
                        `questions.${activeQuestionIndex}._data_status`,
                        calculateQuizDataStatus(activeDataStatus, QuizDataStatus.UPDATE) as QuizDataStatus,
                      );
                    }
                  }}
                />
              )}
            />
          </Show>

          <Controller
            control={form.control}
            name={
              `questions.${activeQuestionIndex}.question_settings.question_mark` as 'questions.0.question_settings.question_mark'
            }
            rules={{
              min: 0,
            }}
            render={(controllerProps) => (
              <FormInput
                {...controllerProps}
                label={__('Point For This Question', 'tutor')}
                type="number"
                isInlineLabel
                placeholder="0"
                style={css`
                  max-width: 80px;
                `}
                onChange={() => {
                  if (calculateQuizDataStatus(activeDataStatus, QuizDataStatus.UPDATE)) {
                    form.setValue(
                      `questions.${activeQuestionIndex}._data_status`,
                      calculateQuizDataStatus(activeDataStatus, QuizDataStatus.UPDATE) as QuizDataStatus,
                    );
                  }
                }}
              />
            )}
          />

          <Controller
            control={form.control}
            name={
              `questions.${activeQuestionIndex}.question_settings.show_question_mark` as 'questions.0.question_settings.show_question_mark'
            }
            render={(controllerProps) => (
              <FormSwitch
                {...controllerProps}
                label={__('Display Points', 'tutor')}
                onChange={() => {
                  if (calculateQuizDataStatus(activeDataStatus, QuizDataStatus.UPDATE)) {
                    form.setValue(
                      `questions.${activeQuestionIndex}._data_status`,
                      calculateQuizDataStatus(activeDataStatus, QuizDataStatus.UPDATE) as QuizDataStatus,
                    );
                  }
                }}
              />
            )}
          />

          <CourseBuilderInjectionSlot
            section="Curriculum.Quiz.bottom_of_question_sidebar"
            namePrefix={`questions.${activeQuestionIndex}.`}
            form={form}
          />
        </div>
      </div>
    </div>
  );
};

export default QuestionConditions;

const styles = {
  emptyQuestions: css`
    padding: ${spacing[12]} ${spacing[32]} ${spacing[24]} ${spacing[24]};
    ${typography.caption('medium')};
  `,
  questionTypeWrapper: css`
    ${styleUtils.display.flex('column')};
    padding: ${spacing[8]} ${spacing[32]} ${spacing[24]} ${spacing[24]};
    gap: ${spacing[10]};
    border-bottom: 1px solid ${colorTokens.stroke.divider};
  `,
  questionTypeRow: css`
    ${styleUtils.display.flex('row')};
    align-items: center;
    gap: ${spacing[10]};
    justify-content: space-between;
    width: 100%;
  `,
  questionType: css`
    display: flex;
    align-items: center;
    gap: ${spacing[10]};
  `,
  conditions: css`
    padding: ${spacing[8]} ${spacing[32]} ${spacing[24]} ${spacing[24]};
    p {
      ${typography.body('medium')};
      color: ${colorTokens.text.primary};
    }
  `,
  conditionControls: css`
    ${styleUtils.display.flex('column')};
    gap: ${spacing[16]};
    margin-top: ${spacing[16]};
  `,
};
