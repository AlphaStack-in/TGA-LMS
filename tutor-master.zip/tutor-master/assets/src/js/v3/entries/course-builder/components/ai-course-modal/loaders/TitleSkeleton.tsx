import { css } from '@emotion/react';

import Skeleton from '@TutorShared/atoms/Skeleton';

import { spacing } from '@TutorShared/config/styles';

const TitleSkeleton = () => {
  return (
    <div css={styles.wrapper}>
      <Skeleton isMagicAi animation width="24px" height="24px" isRound />
      <Skeleton isMagicAi animation width="100%" height="24px" />
    </div>
  );
};

export default TitleSkeleton;
const styles = {
  wrapper: css`
    display: flex;
    align-items: center;
    gap: ${spacing[16]};
    width: 100%;
  `,
};
