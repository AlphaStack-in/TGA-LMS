import { memo, useRef, useState } from 'react';
import { useFormContext } from 'react-hook-form';
import { type SyntheticListenerMap } from '@dnd-kit/core/dist/hooks/utilities';
import { css } from '@emotion/react';
import { useQueryClient } from '@tanstack/react-query';
import { __, sprintf } from '@wordpress/i18n';

import LoadingSpinner from '@TutorShared/atoms/LoadingSpinner';
import ProBadge from '@TutorShared/atoms/ProBadge';
import SVGIcon from '@TutorShared/atoms/SVGIcon';
import Tooltip from '@TutorShared/atoms/Tooltip';

import { useModal } from '@TutorShared/components/modals/Modal';

import { tutorConfig } from '@TutorShared/config/config';
import { Addons, CURRENT_VIEWPORT } from '@TutorShared/config/constants';
import { borderRadius, Breakpoint, colorTokens, spacing } from '@TutorShared/config/styles';
import { typography } from '@TutorShared/config/typography';
import Show from '@TutorShared/controls/Show';
import { AnimationType } from '@TutorShared/hooks/useAnimation';
import { POPOVER_PLACEMENTS } from '@TutorShared/hooks/usePortalPopover';
import { type IconCollection } from '@TutorShared/icons/types';
import ConfirmationPopover from '@TutorShared/molecules/ConfirmationPopover';
import Popover from '@TutorShared/molecules/Popover';
import { styleUtils } from '@TutorShared/utils/style-utils';
import type { ID, TopicContentType } from '@TutorShared/utils/types';
import { isAddonEnabled, noop } from '@TutorShared/utils/util';

import GoogleMeetForm from '@CourseBuilderComponents/additional/meeting/GoogleMeetForm';
import ZoomMeetingForm from '@CourseBuilderComponents/additional/meeting/ZoomMeetingForm';
import AssignmentModal from '@CourseBuilderComponents/modals/AssignmentModal';
import LessonModal from '@CourseBuilderComponents/modals/LessonModal';
import QuizModal from '@CourseBuilderComponents/modals/QuizModal';
import type { CourseTopicWithCollapse } from '@CourseBuilderPages/Curriculum';
import type { CourseDetailsResponse, CourseFormData } from '@CourseBuilderServices/course';
import {
  useDeleteContentBankContentMutation,
  useDeleteContentMutation,
  useDuplicateContentMutation,
} from '@CourseBuilderServices/curriculum';
import { useDeleteQuizMutation, useExportQuizMutation } from '@CourseBuilderServices/quiz';
import { getCourseId, getIdWithoutPrefix } from '@CourseBuilderUtils/utils';

interface TopicContentProps {
  type: TopicContentType;
  topic: CourseTopicWithCollapse;
  content: { id: ID; title: string; total_question: number };
  listeners?: SyntheticListenerMap;
  isDragging?: boolean;
  onDelete?: () => void;
  onCopy?: () => void;
}

const icons = {
  lesson: {
    name: 'lesson',
    color: colorTokens.icon.default,
  },
  tutor_quiz: {
    name: 'quiz',
    color: colorTokens.design.warning,
  },
  tutor_assignments: {
    name: 'assignment',
    color: colorTokens.icon.processing,
  },
  tutor_zoom_meeting: {
    name: 'zoomColorize',
    color: '',
  },
  'tutor-google-meet': {
    name: 'googleMeetColorize',
    color: '',
  },
  tutor_h5p_quiz: {
    name: 'interactiveQuiz',
    color: '#C984FE',
  },
  'cb-lesson': {
    name: 'lesson',
    color: colorTokens.icon.default,
  },
  'cb-assignment': {
    name: 'assignment',
    color: colorTokens.icon.processing,
  },
} as const;

const confirmationMessages = {
  tutor_assignments:
    // prettier-ignore
    __('Are you sure you want to delete this assignment? All existing assignment submissions will be permanently deleted.', 'tutor'),
  tutor_quiz:
    // prettier-ignore
    __('Are you sure you want to delete this quiz? All existing quiz attempts will be permanently deleted.', 'tutor'),
  tutor_h5p_quiz:
    // prettier-ignore
    __( 'Are you sure you want to delete this interactive quiz? All existing quiz attempts will be permanently deleted.', 'tutor'),
} as const;

const modalComponent: {
  [key in Exclude<
    TopicContentType,
    'cb-lesson' | 'tutor_zoom_meeting' | 'tutor-google-meet'
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
  >]: React.FunctionComponent<any>;
} = {
  lesson: LessonModal,
  tutor_quiz: QuizModal,
  tutor_assignments: AssignmentModal,
  tutor_h5p_quiz: QuizModal,
} as const;

const modalTitle: {
  [key in Exclude<TopicContentType, 'cb-lesson' | 'tutor_zoom_meeting' | 'tutor-google-meet'>]: string;
} = {
  lesson: __('Lesson', 'tutor'),
  tutor_quiz: __('Quiz', 'tutor'),
  tutor_assignments: __('Assignment', 'tutor'),
  tutor_h5p_quiz: __('Interactive Quiz', 'tutor'),
} as const;

const modalIcon: {
  [key in Exclude<TopicContentType, 'cb-lesson' | 'tutor_zoom_meeting' | 'tutor-google-meet'>]: IconCollection;
} = {
  lesson: 'lesson',
  tutor_quiz: 'quiz',
  tutor_assignments: 'assignment',
  tutor_h5p_quiz: 'interactiveQuiz',
} as const;

const editAbleContentTypes = [
  'lesson',
  'tutor_assignments',
  'tutor_quiz',
  'tutor_h5p_quiz',
  'tutor_zoom_meeting',
  'tutor-google-meet',
];

const isTutorPro = !!tutorConfig.tutor_pro_url;
const courseId = getCourseId();

const TopicContent = ({ type, topic, content, listeners, isDragging = false, onCopy, onDelete }: TopicContentProps) => {
  const topicId = getIdWithoutPrefix('topic-', topic.id);
  const contentId = getIdWithoutPrefix('content-', content.id);

  const queryClient = useQueryClient();
  const courseDetails = queryClient.getQueryData(['CourseDetails', Number(courseId)]) as CourseDetailsResponse;
  const form = useFormContext<CourseFormData>();
  const [meetingType, setMeetingType] = useState<'tutor_zoom_meeting' | 'tutor-google-meet' | null>(null);
  const [isDeletePopoverOpen, setIsDeletePopoverOpen] = useState(false);

  const editButtonRef = useRef<HTMLButtonElement>(null);
  const deleteRef = useRef<HTMLButtonElement>(null);

  const icon = icons[type] || {
    name: 'lesson',
    color: colorTokens.icon.default,
  };

  const { showModal } = useModal();
  const duplicateContentMutation = useDuplicateContentMutation();
  const deleteContentMutation = useDeleteContentMutation();
  const deleteQuizMutation = useDeleteQuizMutation();
  const deleteGoogleMeetMutation = useDeleteContentMutation();
  const deleteZoomMeetingMutation = useDeleteContentMutation();
  const exportQuizMutation = useExportQuizMutation();
  const deleteContentBankContentMutation = useDeleteContentBankContentMutation();

  const handleShowModalOrPopover = () => {
    const contentType = type as keyof typeof modalComponent;
    if (modalComponent[contentType]) {
      showModal({
        component: modalComponent[contentType],
        props: {
          contentDripType: form.watch('contentDripType'),
          topicId: topicId,
          lessonId: contentId,
          assignmentId: contentId,
          quizId: contentId,
          title: modalTitle[contentType],
          /* translators: %s is the topic title */
          subtitle: sprintf(__('Topic: %s', 'tutor'), topic.title),
          icon: <SVGIcon name={modalIcon[contentType]} height={24} width={24} />,
          ...(type === 'tutor_h5p_quiz' && {
            contentType: 'tutor_h5p_quiz',
          }),
        },
        closeOnEscape: !['tutor_quiz', 'tutor_h5p_quiz'].includes(type),
      });
    }
    if (type === 'tutor_zoom_meeting') {
      setMeetingType('tutor_zoom_meeting');
    }

    if (type === 'tutor-google-meet') {
      setMeetingType('tutor-google-meet');
    }
  };

  const handleDelete = async () => {
    if (['lesson', 'tutor_assignments'].includes(type)) {
      await deleteContentMutation.mutateAsync(contentId);
    } else if (['tutor_quiz', 'tutor_h5p_quiz'].includes(type)) {
      await deleteQuizMutation.mutateAsync(contentId);
    } else if (type === 'tutor-google-meet') {
      await deleteGoogleMeetMutation.mutateAsync(contentId);
    } else if (type === 'tutor_zoom_meeting') {
      await deleteZoomMeetingMutation.mutateAsync(contentId);
    } else if (['cb-lesson', 'cb-assignment'].includes(type)) {
      await deleteContentBankContentMutation.mutateAsync({ topicId, contentId });
    }

    setIsDeletePopoverOpen(false);
    onDelete?.();
  };

  const handleDuplicate = () => {
    const convertedContentType: {
      [key in Exclude<TopicContentType, 'cb-lesson' | 'tutor_zoom_meeting' | 'tutor-google-meet'>]:
        | 'lesson'
        | 'assignment'
        | 'answer'
        | 'question'
        | 'quiz'
        | 'topic';
    } = {
      lesson: 'lesson',
      tutor_assignments: 'assignment',
      tutor_quiz: 'quiz',
      tutor_h5p_quiz: 'quiz',
    } as const;

    duplicateContentMutation.mutateAsync({
      course_id: courseId,
      content_id: contentId,
      content_type:
        convertedContentType[
          type as Exclude<TopicContentType, 'cb-lesson' | 'tutor_zoom_meeting' | 'tutor-google-meet'>
        ],
    });
    onCopy?.();
  };

  return (
    <>
      <div
        css={styles.wrapper({
          isDragging,
          isActive: meetingType === type || isDeletePopoverOpen || duplicateContentMutation.isPending,
        })}
      >
        <div css={styles.iconAndTitle({ isDragging })} {...listeners}>
          <div data-content-icon>
            <SVGIcon
              name={icon.name as IconCollection}
              width={24}
              height={24}
              style={css`
                color: ${icon.color};
              `}
            />
          </div>
          <div data-bar-icon>
            <SVGIcon name="bars" width={24} height={24} />
          </div>
          <p css={styles.title} onClick={handleShowModalOrPopover} onKeyDown={noop}>
            <span dangerouslySetInnerHTML={{ __html: content.title }} />
            <Show when={(type === 'tutor_quiz' || type === 'tutor_h5p_quiz') && !!content.total_question}>
              <span data-question-count>
                (
                {
                  /* translators: %s is the total number of questions */
                  sprintf(__('%s Questions', 'tutor'), content.total_question)
                }
                )
              </span>
            </Show>
          </p>
        </div>

        <div css={styles.actions} data-actions>
          <Show when={type === 'tutor_quiz'}>
            <Tooltip content={__('Export Quiz', 'tutor')} delay={200}>
              <Show
                when={!isTutorPro}
                fallback={
                  <Show when={isAddonEnabled(Addons.QUIZ_EXPORT_IMPORT)}>
                    <button
                      type="button"
                      css={styleUtils.actionButton}
                      onClick={() => {
                        exportQuizMutation.mutate(contentId);
                      }}
                    >
                      <SVGIcon name="export" width={24} height={24} />
                    </button>
                  </Show>
                }
              >
                <ProBadge size="tiny">
                  <button type="button" css={styleUtils.actionButton} disabled onClick={noop}>
                    <SVGIcon name="export" width={24} height={24} />
                  </button>
                </ProBadge>
              </Show>
            </Tooltip>
          </Show>
          <Show when={editAbleContentTypes.includes(type)}>
            <Tooltip content={__('Edit', 'tutor')} delay={200}>
              <button
                data-cy={`edit-${type}`}
                ref={editButtonRef}
                type="button"
                css={styleUtils.actionButton}
                onClick={handleShowModalOrPopover}
              >
                <SVGIcon name="edit" width={24} height={24} />
              </button>
            </Tooltip>
          </Show>
          <Show when={!['tutor_zoom_meeting', 'tutor_zoom_meeting'].includes(type)}>
            <Show when={!duplicateContentMutation.isPending} fallback={<LoadingSpinner size={24} />}>
              <Tooltip content={__('Duplicate', 'tutor')} delay={200}>
                <Show
                  when={!isTutorPro}
                  fallback={
                    <button
                      data-cy={`duplicate-${type}`}
                      type="button"
                      css={styleUtils.actionButton}
                      onClick={handleDuplicate}
                    >
                      <SVGIcon name="copyPaste" width={24} height={24} />
                    </button>
                  }
                >
                  <ProBadge size="tiny">
                    <button disabled type="button" css={styleUtils.actionButton} onClick={noop}>
                      <SVGIcon name="copyPaste" width={24} height={24} />
                    </button>
                  </ProBadge>
                </Show>
              </Tooltip>
            </Show>
          </Show>
          <Tooltip content={__('Delete', 'tutor')} delay={200}>
            <button
              data-cy={`delete-${type}`}
              ref={deleteRef}
              type="button"
              css={styleUtils.actionButton}
              onClick={() => {
                setIsDeletePopoverOpen(true);
              }}
            >
              <SVGIcon name="delete" width={24} height={24} />
            </button>
          </Tooltip>
        </div>
      </div>
      <Popover
        triggerRef={editButtonRef}
        isOpen={meetingType !== null}
        closePopover={noop}
        maxWidth="306px"
        closeOnEscape={false}
        placement={CURRENT_VIEWPORT.isAboveMobile ? POPOVER_PLACEMENTS.BOTTOM : POPOVER_PLACEMENTS.ABSOLUTE_CENTER}
      >
        <Show when={meetingType === 'tutor_zoom_meeting'}>
          <ZoomMeetingForm
            data={null}
            topicId={topicId}
            meetingHost={courseDetails?.zoom_users || {}}
            onCancel={() => setMeetingType(null)}
            meetingId={contentId}
          />
        </Show>
        <Show when={meetingType === 'tutor-google-meet'}>
          <GoogleMeetForm data={null} topicId={topicId} onCancel={() => setMeetingType(null)} meetingId={contentId} />
        </Show>
      </Popover>
      <ConfirmationPopover
        isOpen={isDeletePopoverOpen}
        isLoading={
          deleteContentMutation.isPending ||
          deleteQuizMutation.isPending ||
          deleteGoogleMeetMutation.isPending ||
          deleteZoomMeetingMutation.isPending ||
          deleteContentBankContentMutation.isPending
        }
        triggerRef={deleteRef}
        closePopover={noop}
        maxWidth="258px"
        title={
          // translators: %s is the title of the item to be deleted
          sprintf(__('Delete "%s"', 'tutor'), content.title)
        }
        message={
          confirmationMessages[type as keyof typeof confirmationMessages] ||
          __('Are you sure you want to delete this content from your course? This cannot be undone.', 'tutor')
        }
        animationType={AnimationType.slideUp}
        confirmButton={{
          text: __('Delete', 'tutor'),
          variant: 'text',
          isDelete: true,
        }}
        cancelButton={{
          text: __('Cancel', 'tutor'),
          variant: 'text',
        }}
        onConfirmation={handleDelete}
        onCancel={() => setIsDeletePopoverOpen(false)}
      />
    </>
  );
};

export default memo(TopicContent, (prev, next) => {
  return (
    prev.content.id === next.content.id &&
    prev.content.title === next.content.title &&
    prev.content.total_question === next.content.total_question &&
    prev.isDragging === next.isDragging
  );
});

const styles = {
  wrapper: ({
    isDragging = false,
    isActive: isMeetingSelected = false,
  }: {
    isDragging: boolean;
    isActive: boolean;
  }) => css`
    width: 100%;
    padding: ${spacing[10]} ${spacing[8]};
    border: 1px solid transparent;
    border-radius: ${borderRadius[6]};
    display: flex;
    justify-content: space-between;
    align-items: center;
    opacity: 1;

    ${isDragging &&
    css`
      background-color: ${colorTokens.stroke.hover};
      opacity: 0.3;
    `}

    [data-content-icon],
    [data-bar-icon] {
      display: flex;
      height: 24px;
    }

    :hover,
    :focus-within {
      border-color: ${colorTokens.stroke.border};
      background-color: ${colorTokens.background.white};

      [data-content-icon] {
        display: none;
      }
      [data-bar-icon] {
        display: block;
      }

      [data-actions] {
        opacity: ${isDragging ? 0 : 1};
      }
    }

    ${isMeetingSelected &&
    css`
      border-color: ${colorTokens.stroke.border};
      background-color: ${colorTokens.background.white};
      [data-content-icon] {
        display: flex;
      }
      [data-bar-icon] {
        display: none;
      }
      [data-actions] {
        opacity: 1;
      }
    `}

    ${Breakpoint.smallTablet} {
      [data-actions] {
        opacity: 1;
      }
    }
  `,
  title: css`
    ${typography.caption()};
    color: ${colorTokens.text.title};
    display: flex;
    align-items: center;
    gap: ${spacing[4]};
    cursor: pointer;

    span {
      &:first-of-type {
        ${styleUtils.text.ellipsis(2)}
      }
    }

    [data-question-count] {
      color: ${colorTokens.text.hints};
    }
  `,
  iconAndTitle: ({ isDragging = false }) => css`
    display: flex;
    align-items: center;
    gap: ${spacing[8]};
    cursor: grab;
    flex-grow: 1;

    [data-bar-icon] {
      display: none;
    }
    ${isDragging &&
    css`
      [data-content-icon] {
        display: none;
      }
      [data-bar-icon] {
        display: block;
      }
      cursor: grabbing;
    `}
  `,
  actions: css`
    display: flex;
    opacity: 0;
    align-items: start;
    gap: ${spacing[8]};
    justify-content: end;
  `,
};
